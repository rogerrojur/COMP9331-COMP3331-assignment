public class ReOrder {
    //default value is ok
    private STP stp;
    private boolean working;
    private int target;
    private int nbHaveForward;
    @Override
    public String toString() {
        if (stp == null)
            return "nothing";
        else {
            return String.valueOf(stp.getSeqNb().longValue()) + "; " + String.valueOf(target);
        }
    }
    public boolean state() {
        return working;
    }
    public boolean canReOrder() {
        return !state();
    }
    public void newReOrder(STP stp, int order) {
        this.stp = stp;
        working = true;
        target = order;
        nbHaveForward = 0;
    }
    public STP process() {
        if (state()) {
            if(++nbHaveForward == target) {
                STP r = stp;
                stp = null;
                working = false;
                target = 0;
                nbHaveForward = 0;
                return r;
            }
        }
        return null;
    }
}
