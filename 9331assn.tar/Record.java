import java.util.*;
import java.io.*;

public class Record {
    class RecordNode {
        private String event;
        private float time;
        private String typeOfPacket;
        private long seqNb;
        private int NbOfData;
        private long ackNb;
        public String getEvent() {
            return event;
        }
        public RecordNode(String event, float time, String typeOfPacket, long seqNb, int NbOfData, long ackNb) {
            this.event = event;
            this.time = time;
            this.typeOfPacket = typeOfPacket;
            this.seqNb = seqNb;
            this.NbOfData = NbOfData;
            this.ackNb = ackNb;
        }
        public String getSpace(int total, String s) {
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < total - s.length(); i++)
                sb.append(" ");
            sb.append(s);
            return sb.toString();
        }
        public String getSpace(int total, String s1, String s2) {
            StringBuilder sb = new StringBuilder();
            sb.append(s1);
            for (int i = 0; i < total - s1.length() - s2.length(); i++)
                sb.append(" ");
            sb.append(s2);
            return sb.toString();
        }
        public float castFloat(float src) {
            return (float)(Math.round(src * 100)) / 100;
        }
        @Override
        public String toString() {
            return getSpace(35, event, String.valueOf(castFloat(time))) + getSpace(10, typeOfPacket) + getSpace(25, String.valueOf(seqNb)) + getSpace(15, String.valueOf(NbOfData)) + getSpace(15, String.valueOf(ackNb));
        }
    }
    private volatile LinkedList<RecordNode> list;
    private volatile PrintWriter out;
    public LinkedList<RecordNode> getList() {
        return list;
    }
    public Record(PrintWriter out) {
        list = new LinkedList<RecordNode>();
        this.out = out;
    }
    public synchronized void addRecord(String event, float time, String typeOfPacket, long seqNb, int NbOfData, long ackNb) {
        list.add(new RecordNode(event, time, typeOfPacket, seqNb, NbOfData, ackNb));
        System.out.println(list.getLast());
        out.println(list.getLast().toString());
    }
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < list.size(); i++)
            sb.append(list.get(i).toString()).append(System.getProperty("line.separator"));
        return sb.toString();
    }
    public int nbOfRecord() {
        return list.size();
    }
    public void dispose() {
        if (out != null)
            out.close();
    }
    public synchronized void writeContent(String s) {
        out.print(s);
    }
    public String getNew() {
        return list.getLast().getEvent();
    }
    public static void main(String []args) {
    }
}
