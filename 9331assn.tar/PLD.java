import java.util.*;

public class PLD {
    private float pDrop;
    private float pDuplicate;
    private float pCorrupt;
    private float pOrder;
    private int maxOrder;
    private float pDelay;
    private int maxDelay;
    private int seed;
    private Random random;
    public PLD(float pDrop, float pDuplicate, float pCorrupt, float pOrder, int maxOrder, float pDelay, int maxDelay, int seed) {
        this.pDrop = pDrop;
        this.pDuplicate = pDuplicate;
        this.pCorrupt = pCorrupt;
        this.pOrder = pOrder;
        this.maxOrder = maxOrder;
        this.pDelay = pDelay;
        this.maxDelay = maxDelay;
        this.seed = seed;
        random = new Random(this.seed);
    }
    private boolean doneIt(float prob) {
        if (random.nextFloat() < prob)
            return true;
        return false;
    }
    public String decision() {
        if (doneIt(pDrop))
            return "Drop";
        else if (doneIt(pDuplicate))
            return "Duplicate";
        else if (doneIt(pCorrupt))
            return "Corrupt";
        else if (doneIt(pOrder))
            return "ReOrder";
        else if (doneIt(pDelay))
            return "Delay";
        else
            return "Forward";
    }
    public int getDelay() {
        return random.nextInt(maxDelay + 1);
    }
    public int getReOrder() {
        return random.nextInt(maxOrder) + 1;
    }
}
