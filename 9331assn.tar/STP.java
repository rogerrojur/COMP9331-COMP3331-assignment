import java.util.*;

class NotCompleteInfoException extends Exception {}

class IncorrectValueException extends Exception {}

public class STP {
    private static long STPCount = 0;
    private final long STPId = STPCount++;
    private String srcIP;
    private String destIP;
    private Integer srcPort;
    private Integer destPort;
    private Long seqNb;
    private Long ackNb;
    private static final Integer headLength = 36;//4*2IP 2*2port seq/ack 4*2 flag/tcplength 2 MWS 2 MSS 2 timestamp 8 payloadsize 2
    private Byte flag;//SYN, ACK, FIN, RST, CS
    private Integer MWS;
    private Integer MSS;
    private long timeStamp;
    private Integer totalSize;
    private LinkedList<Byte> payLoad;//payLoad.size() is the length of payLoad
    private LinkedList<Byte> header;
    private Boolean checkSum;//only for 1 bit error: 1 is odd 0 is even
    public byte []initSTP(byte []data, boolean hi) {//general init
        setHeader();
        byte []r = setPayLoad(data);
        encodeCheckSum();
        return r;
    }
    public void initSTP(byte []data) {//just copy
        setHeader();
        setPayLoad(data);
    }
    public String getSrcIP() {
        return srcIP;
    }
    public String getDestIP() {
        return destIP;
    }
    public Integer getSrcPort() {
        return srcPort;
    }
    public Integer getDestPort() {
        return destPort;
    }
    private static int bitGet(boolean flag, int index) {
        if (flag)
            return (int)Math.pow(2, index);
        return 0;
    }
    public Long getAckNb() {
        return ackNb;
    }
    public void resetTS() {
        timeStamp = System.currentTimeMillis();
    }
    public Long getSeqNb() {
        return seqNb;
    }
    public LinkedList<Byte> getPayLoad() {
        return payLoad;
    }
    public Integer getPayLoadSize() {
        return payLoad.size();
    }
    public Integer getTotalSize() {
        return totalSize;
    }
    public static Integer getHeadLength() {
        return headLength;
    }
    public void updateTotalSize() {
        totalSize = 0;
        if (header != null)
            totalSize += header.size();
        if (payLoad != null)
            totalSize += payLoad.size();
    }
    public int getPayLoadLength() {
        if (payLoad == null)
            return 0;
        return payLoad.size();
    }
    private static long byteArrToValue(byte []seg) {//need to be slience
        long result = 0;
        for (int i = 0; i < seg.length - 1; i++) {
            int temp = byteToInt(Byte.valueOf(seg[i]));
            result += (long)(temp <<= ((seg.length - 1 - i) * 8));
        }
        return (result += byteToInt(Byte.valueOf(seg[seg.length - 1])));
    }
    private static long process(byte []seg, int start, int end) {
        byte []me = Arrays.copyOfRange(seg, start, end);
        return byteArrToValue(me);
    }
    public static String parseSrcIP(byte []seg) {
        int ad1 = byteToInt(Byte.valueOf(seg[0]));
        int ad2 = byteToInt(Byte.valueOf(seg[1]));
        int ad3 = byteToInt(Byte.valueOf(seg[2]));
        int ad4 = byteToInt(Byte.valueOf(seg[3]));
        return String.valueOf(ad1) + "." + String.valueOf(ad2) + "." + String.valueOf(ad3) + "." + String.valueOf(ad4);
    }
    public static String parseDestIP(byte []seg) {
        int ad1 = byteToInt(Byte.valueOf(seg[4]));
        int ad2 = byteToInt(Byte.valueOf(seg[5]));
        int ad3 = byteToInt(Byte.valueOf(seg[6]));
        int ad4 = byteToInt(Byte.valueOf(seg[7]));
        return String.valueOf(ad1) + "." + String.valueOf(ad2) + "." + String.valueOf(ad3) + "." + String.valueOf(ad4);
    }
    public static Integer parseSrcPort(byte []seg) {
        return Integer.valueOf((int)process(seg, 8, 10));
    }
    public static Integer parsePayLoadLength(byte []seg) {
        return Integer.valueOf((int)process(seg, 34, 36));
    }
    public static Integer parseDestPort(byte []seg) {
        return Integer.valueOf((int)process(seg, 10, 12));
    }
    public static Long parseSeqNb(byte []seg) {
        return Long.valueOf(process(seg, 12, 16));
    }
    public static Long parseAckNb(byte []seg) {
        return Long.valueOf(process(seg, 16, 20));
    }
    public static Integer parseHeadLength(byte []seg) {
        //System.out.println(String.valueOf(seg[20]));
        return Integer.valueOf(byteToInt(Byte.valueOf(seg[20])));
    }
    public static Byte parseFlag(byte []seg) {
        return seg[21];
    }
    public static String analyseFlag(byte flag) {
        StringBuilder sb = new StringBuilder();
        if ((flag & 1) == 1)
            sb.append(" ").append("CS");
        if (((flag >>= 1) & 1) == 1)
            sb.append(" ").append("RST");
        if (((flag >>= 1) & 1) == 1)
            sb.append(" ").append("FIN");
        if (((flag >>= 1) & 1) == 1)
            sb.append(" ").append("ACK");
        if (((flag >>= 1) & 1) == 1)
            sb.append(" ").append("SYN");
        return sb.toString();
    }
    public static boolean isCS(byte flag) {
        if ((flag & 1) == 1)
            return true;
        return false;
    }
    public static boolean isRST(byte flag) {
        if (((flag >>= 1) & 1) == 1)
            return true;
        return false;
    }
    public static boolean isFIN(byte flag) {
        if (((flag >>= 2) & 1) == 1)
            return true;
        return false;
    }
    public static boolean isACK(byte flag) {
        if (((flag >>= 3) & 1) == 1)
            return true;
        return false;
    }
    public static boolean isSYN(byte flag) {
        if (((flag >>= 4) & 1) == 1)
            return true;
        return false;
    }
    public static Integer parseMWS(byte []seg) {
        return Integer.valueOf((int)process(seg, 22, 24));
    }
    public static Integer parseMSS(byte []seg) {
        return Integer.valueOf((int)process(seg, 24, 26));
    }
    public static Long parseTS(byte []seg) {
        return Long.valueOf(process(seg, 26, 34));
    }
    public static boolean parseCheckSum(byte []seg) {
        return (parseFlag(seg).byteValue() & 1) == 1;
    }
    public static String analyseCheckSum(byte []seg) {
        if (parseCheckSum(seg))
            return "odd";
        else
            return "even";
    }
    public static String parseHeader(byte []seg) {
        StringBuilder sb = new StringBuilder("header:\n");
        sb.append("srcIP: ").append(parseSrcIP(seg)).append("\n");
        sb.append("destIP: ").append(parseDestIP(seg)).append("\n");
        sb.append("srcPort: ").append(String.valueOf(parseSrcPort(seg))).append("\n");
        sb.append("destPort: ").append(String.valueOf(parseDestPort(seg))).append("\n");
        sb.append("seqNb: ").append(String.valueOf(parseSeqNb(seg))).append("\n");
        sb.append("ackNb: ").append(String.valueOf(parseAckNb(seg))).append("\n");
        sb.append("headLength: ").append(String.valueOf(parseHeadLength(seg))).append("\n");
        sb.append("Flag:").append(analyseFlag(parseFlag(seg).byteValue())).append("\n");
        sb.append("MWS: ").append(String.valueOf(parseMWS(seg))).append("\n");
        sb.append("MSS: ").append(String.valueOf(parseMSS(seg))).append("\n");
        sb.append("timeStamp: ").append(String.valueOf(parseTS(seg))).append("\n");
        sb.append("payLoadLength: ").append(String.valueOf(parsePayLoadLength(seg))).append("\n");
        return sb.toString();
    }
    public static byte[] extractPayLoad(byte []seg) {
        int temp = parseHeadLength(seg).intValue();
        return Arrays.copyOfRange(seg, temp, seg.length);
    }
    public static String parsePayLoad(byte []seg) {
        return "payLoad:\n" + new String(extractPayLoad(seg)) + "\n";
    }
    public static String parseSegment(byte []seg) {
        return parseHeader(seg) + parseHeader(seg);
    }
    public static byte []translator(LinkedList<Byte> source) {
        byte []result = new byte[source.size()];
        for (int i = 0; i < source.size(); i++)
            result[i] = source.get(i).byteValue();
        return result;
    }
    public String headerValueIs() {
        if (header == null)
            return "";
        byte []temp = translator(header);
        return new String(temp);
    }
    public String payLoadValueIs() {
        if (payLoad == null)
            return "";
        byte []temp = translator(payLoad);
        return new String(temp);
    }
    @Override
    public String toString() {
        return "srcIP: " + srcIP + "\ndestIP: " + destIP + "\nsrcPort: " +
            String.valueOf(srcPort) + "\ndestPort: " +
            String.valueOf(destPort) + "\nseqNb: " + String.valueOf(seqNb) +
            "\nackNb: " + String.valueOf(ackNb) + "\nheadLength: " +
            String.valueOf(headLength) + "\nFlag: " +
            String.valueOf(flag.byteValue()) + "\nMWS: " + String.valueOf(MWS)
            + "\nMSS: " + String.valueOf(MSS) + "\ntimeStamp: " +
            String.valueOf(timeStamp) + "\ncheckSum: " +
        String.valueOf(checkSum) + "\npayLoadLength: " + String.valueOf(getPayLoadLength()) + "\nheader: " + headerValueIs() +
            "\npayLoad: " + payLoadValueIs() + "\n";
    }
    private static byte convertFlag(boolean SYN, boolean ACK, boolean FIN, boolean RST) {
        int myFlag = 0;
        if (RST)
            myFlag += bitGet(RST, 1);
        if (FIN)
            myFlag += bitGet(FIN, 2);
        if (ACK)
            myFlag += bitGet(ACK, 3);
        if (SYN)
            myFlag += bitGet(SYN, 4);
        return (byte)myFlag;
    }
    private byte convertHeadLen() {
        return (byte)headLength.intValue();
    }
    public STP(String srcIP, String destIP, int srcPort, int destPort, long seqNb, long ackNb, int MWS, int MSS, boolean SYN, boolean ACK, boolean FIN, boolean RST) {// checksum CS need to be recalculate later
        this.srcIP = srcIP;
        this.destIP = destIP;
        this.srcPort = srcPort;
        this.destPort = destPort;
        this.seqNb = seqNb;
        this.ackNb = ackNb;
        byte temp = convertFlag(SYN, ACK, FIN, RST);
        this.flag = Byte.valueOf(temp);
        this.MWS = MWS;
        this.MSS = MSS;
        this.timeStamp = System.currentTimeMillis();//or set it when sent
        totalSize = 0;
    }
    public STP(byte[] seg) {//convert byte[] to stp
        this(parseSrcIP(seg), parseDestIP(seg), parseSrcPort(seg), parseDestPort(seg), parseSeqNb(seg), parseAckNb(seg), parseMWS(seg), parseMSS(seg), false, false, false, false);
        flag = parseFlag(seg);
        timeStamp = parseTS(seg);
    }
    private static LinkedList<Byte> translatePort(int port) {
        LinkedList<Byte> result = new LinkedList<Byte>(Arrays.asList(Byte.valueOf((byte)0), Byte.valueOf((byte)0)));
        result.set(1, (byte)(port & 0xFF));
        result.set(0, (byte)((port >>= 8) & 0xFF));
        return result;
    }
    private static LinkedList<Byte> translatePayLoadLength(int payLoadLength) {
        LinkedList<Byte> result = new LinkedList<Byte>(Arrays.asList(Byte.valueOf((byte)0), Byte.valueOf((byte)0)));
        result.set(1, (byte)(payLoadLength & 0xFF));
        result.set(0, (byte)((payLoadLength >>= 8) & 0xFF));
        return result;
    }
    private static LinkedList<Byte> translateNb(long number, int len) {
        LinkedList<Byte> result = new LinkedList<Byte>(Arrays.asList(Byte.valueOf((byte)0), Byte.valueOf((byte)0), Byte.valueOf((byte)0), Byte.valueOf((byte)0), Byte.valueOf((byte)0), Byte.valueOf((byte)0), Byte.valueOf((byte)0), Byte.valueOf((byte)0)));
        result.set(len - 1, (byte)(number & 0xFF));
        for (int i = 1; i < len; i++)
            result.set(len - 1 - i, (byte)((number >>= 8) & 0xFF));
        for (int i = 0; i < 8 - len; i++)
            result.removeLast();
        return result;
    }
    private static LinkedList<Byte> translateIP(String IP) {
        String []subAdd = IP.split("\\.");
        Integer address = Integer.valueOf(subAdd[3]) + (Integer.valueOf(subAdd[2]) << 8) + (Integer.valueOf(subAdd[1]) << 16) + (Integer.valueOf(subAdd[0]) << 24);
        return translateNb(address, 4);
    }
    public int parseFlag() {
        int result = (int)flag;
        if (result < 0)
            result += 256;
        return result;
    }
    public void printFlag() {
        int cur = parseFlag();
        if ((cur & 1) == 1)
            System.out.print("CS ");
        if (((cur >>= 1) & 1) == 1)
            System.out.print("RST ");
        if (((cur >>= 1) & 1) == 1)
            System.out.print("FIN ");
        if (((cur >>= 1) & 1) == 1)
            System.out.print("ACK ");
        if (((cur >>= 1) & 1) == 1)
            System.out.println("SYN");
    }
    private LinkedList<Byte> translateSeqNb() {
        return translateNb(seqNb, 4);
    }
    private LinkedList<Byte> translateAckNb() {
        return translateNb(ackNb, 4);
    }
    private LinkedList<Byte> translateMWS() {
        return translateNb(MWS, 2);
    }
    private LinkedList<Byte> translateMSS() {
        return translateNb(MSS, 2);
    }
    private LinkedList<Byte> translateTS() {
        return translateNb(timeStamp, 8);
    }
    public void setHeader(){//payLoad first
        header = new LinkedList<Byte>();
        header.addAll(translateIP(srcIP));
        header.addAll(translateIP(destIP));
        header.addAll(translatePort(srcPort));
        header.addAll(translatePort(destPort));
        header.addAll(translateSeqNb());
        header.addAll(translateAckNb());
        header.add(Byte.valueOf(convertHeadLen()));
        header.add(Byte.valueOf(flag));
        header.addAll(translateMWS());
        header.addAll(translateMSS());
        header.addAll(translateTS());
        updateTotalSize();
    }
    public byte[] setPayLoad(byte []seg) {
        payLoad = new LinkedList<Byte>();
        if(seg.length == 0)
            return seg;
        if (seg.length <= MSS) {
            for (int i = 0; i < seg.length; i++)
                payLoad.add(seg[i]);
            header.addAll(translatePayLoadLength(getPayLoadLength()));
            updateTotalSize();
            return new byte[0];
        } else {
            for (int i = 0; i < MSS; i++)
                payLoad.add(seg[i]);
            byte []newSeg = Arrays.copyOfRange(seg, MSS, seg.length);
            header.addAll(translatePayLoadLength(getPayLoadLength()));
            updateTotalSize();
            return newSeg;
        }
    }
    /*
    public String setPayLoad(String data) {//return the rest of the data
        payLoad = new LinkedList<Byte>();
        if (data.equals(""))
            return "";
        byte []temp = data.getBytes();
        if (temp.length <= MSS) {
            for (int i = 0; i < temp.length; i++)
                payLoad.add(temp[i]);
            updateTotalSize();
            return "";
        } else {
            for (int i = 0; i < MSS; i++)
                payLoad.add(temp[i]);
            byte []newTemp = Arrays.copyOfRange(temp, MSS, temp.length);
            updateTotalSize();
            return new String(newTemp);
        }
    }
     */
    public static byte[] listToArr(LinkedList<Byte> list) throws NotCompleteInfoException {
        byte []temp = new byte[list.size()];
        for (int i = 0; i < temp.length; i++)
            temp[i] = list.get(i).byteValue();
        return temp;
    }
    public LinkedList<Byte> getSegment() throws NotCompleteInfoException {
        if (header == null)
            throw new NotCompleteInfoException();
        if (payLoad == null)
            return header;
        LinkedList<Byte> result = new LinkedList<Byte>();
        result.addAll(header);
        result.addAll(payLoad);
        return result;
    }
    public void encodeCheckSum() {
        try {
            calculateCheckSum();
            if (checkSum) {
                byte new_cs = (byte)(decodeCheckSum(header).byteValue() | 1);
                header.set(21, Byte.valueOf(new_cs));
            } else {
                byte new_cs = (byte)(decodeCheckSum(header).byteValue() & 254);
                header.set(21, Byte.valueOf(new_cs));
            }
        } catch (IncorrectValueException e) {
            e.printStackTrace();
        }
    }
    private static int decodeHeadLen(LinkedList<Byte> seg) throws IncorrectValueException {
        if (seg == null)
            throw new IncorrectValueException();
        return byteToInt(seg.get(20));
    }
    private static int byteToInt(Byte b) {
        int cur = (int)b.byteValue();
        if (cur < 0)
            cur += 256;
        return cur;
    }
    private static Byte decodeCheckSum(LinkedList<Byte> seg) throws IncorrectValueException {
        if (seg == null)
            throw new IncorrectValueException();
        return seg.get(21);
    }
    private static void shieldCheckSum(LinkedList<Byte> seg) throws IncorrectValueException {
        byte temp = decodeCheckSum(seg).byteValue();
        byte new_cs = (byte)(temp & 254);
        seg.set(21, Byte.valueOf(new_cs));
    }
    public static boolean checkIt(LinkedList<Byte> seg) {
        int count = 0;
        for (int i = 0; i < seg.size(); i++) {
            int cur = byteToInt(seg.get(i));
            while (cur != 0) {
                count++;
                cur = cur & (cur - 1);
            }
        }
        if (count % 2 == 1)
            return true;
        else
            return false;
    }
    public static boolean outerCalculateCheckSum(LinkedList<Byte> seg) {
        try {
            shieldCheckSum(seg);
        } catch (IncorrectValueException e) {
            e.printStackTrace();
        }
        return checkIt(seg);
    }
    public void calculateCheckSum() {
        LinkedList<Byte> seg = null;
        try {
            seg = getSegment();
            shieldCheckSum(seg);
        } catch (IncorrectValueException | NotCompleteInfoException e) {
            e.printStackTrace();
        }
        checkSum = checkIt(seg);
    }
    public static byte[] corruptSegment(byte []segment) {
        byte firstByte = segment[0];
        if(firstByte % 2 == 0)
            segment[0] = (byte)(segment[0] + 1);
        else
            segment[0] = (byte)(segment[0] - 1);
        return segment;
    }
    public static void main(String []args) {
        STP stp = new STP("192.168.1.19", "134.179.34.79", 33333, 8888, 45L, 87L, 1024, 772, true, true, true, true);
        //stp.printFlag();
        stp.setHeader();
        stp.setPayLoad("hi! my name is Kai!\n".getBytes());
        /*
        LinkedList<Byte> a = null;
        try {
            a = stp.getSegment();
            stp.shieldCheckSum(a);
        } catch (NotCompleteInfoException | IncorrectValueException e) {
            e.printStackTrace();
        }
        for (int i = 0; i < a.size(); i++)
            System.out.println(byteToInt(a.get(i)));
        */
        //System.out.println(String.valueOf(stp.header.size()));
        //System.out.println("-------------------------------");
        stp.calculateCheckSum();
        //System.out.println("-------------------------------");
        //System.out.println(stp);
        stp.encodeCheckSum();
        System.out.println(stp);
        byte []temp = null;
        try {
            temp = listToArr(stp.getSegment());
        } catch (Exception e) {
            e.printStackTrace();
        }
        System.out.println(parseHeader(temp) + parsePayLoad(temp));
    }
}
