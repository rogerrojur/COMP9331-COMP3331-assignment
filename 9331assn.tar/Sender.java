import java.util.*;
import java.io.*;
import java.net.*;
import java.util.concurrent.*;

class IncorrectArgumentsException extends Exception {}

class SenderData {
    private int sizeOfFile;
    private volatile int segTrasnsmitted;
    private volatile int segByPLD;
    private volatile int segDrop;
    private volatile int segCorr;
    private volatile int segReOrder;
    private volatile int segDup;
    private volatile int segDelay;
    private volatile int retranTO;
    private volatile int fastRetran;
    private volatile int dARece;
    private int getSpace(int len1, int len2) {
        return 100 - len1 - len2;
    }
    private String small(String s, int i) {
        StringBuilder sb = new StringBuilder();
        sb.append(s);
        for (int j = 0; j < getSpace(s.length(), String.valueOf(i).length()); j++)
            sb.append(" ");
        sb.append(String.valueOf(i));
        return sb.toString();
    }
    private String slark() {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 100; i++)
            sb.append("=");
        sb.append(System.getProperty("line.separator"));
        return sb.toString();
    }
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(slark());
        sb.append(small("Size of the file (in Bytes)", sizeOfFile)).append(System.getProperty("line.separator"));
        sb.append(small("Segments transmitted (including drop & RXT)", segTrasnsmitted)).append(System.getProperty("line.separator"));
        sb.append(small("Number of Segments handled by PLD", segByPLD)).append(System.getProperty("line.separator"));
        sb.append(small("Number of Segments dropped", segDrop)).append(System.getProperty("line.separator"));
        sb.append(small("Number of Segments Corrupted", segCorr)).append(System.getProperty("line.separator"));
        sb.append(small("Number of Segments Re-ordered", segReOrder)).append(System.getProperty("line.separator"));
        sb.append(small("Number of Segments Duplicated", segDup)).append(System.getProperty("line.separator"));
        sb.append(small("Number of Segments Delayed", segDelay)).append(System.getProperty("line.separator"));
        sb.append(small("Number of Retransmissions due to TIMEOUT", retranTO)).append(System.getProperty("line.separator"));
        sb.append(small("Number of FAST RETRANSMISSION", fastRetran)).append(System.getProperty("line.separator"));
        sb.append(small("Number of DUP ACKS received", dARece)).append(System.getProperty("line.separator"));
        sb.append(slark());
        return sb.toString();
    }
    public SenderData(int sizeOfFile) {
        this.sizeOfFile = sizeOfFile;
    }
    public synchronized int getST() {
        return segTrasnsmitted;
    }
    public synchronized int getSBP() {
        return segByPLD;
    }
    public synchronized int getSDr() {
        return segDrop;
    }
    public synchronized int getSC() {
        return segCorr;
    }
    public synchronized int getSRO() {
        return segReOrder;
    }
    public synchronized int getSDu() {
        return segDup;
    }
    public synchronized int getSDe() {
        return segDelay;
    }
    public synchronized int getRTTO() {
        return retranTO;
    }
    public synchronized int getFRT() {
        return fastRetran;
    }
    public synchronized int getDAR() {
        return dARece;
    }
    public synchronized void increST() {
        segTrasnsmitted++;
    }
    public synchronized void increSBP() {
        segByPLD++;
    }
    public synchronized void increSDr() {
        segDrop++;
    }
    public synchronized void increSC() {
        segCorr++;
    }
    public synchronized void increSRO() {
        segReOrder++;
    }
    public synchronized void increSDu() {
        segDup++;
    }
    public synchronized void increSDe() {
        segDelay++;
    }
    public synchronized void increRTTO() {
        retranTO++;
    }
    public synchronized void increFRT() {
        fastRetran++;
    }
    public synchronized void increDAR() {
        dARece++;
    }
}

public class Sender {
    private MyTimer myTimer;
    private Window window;
    private DatagramSocket ds;
    private String senderHostIP;
    private int senderHostPort;
    private String receiverHostIP;
    private int receiverHostPort;
    private String fileName;
    private long nextSeq;
    private long nextAck;
    private Integer MWS;
    private Integer MSS;
    private Integer gamma;
    private PLD myPLD;
    private long beginTime;
    private Record record;
    private volatile Boolean finAlready;
    private volatile Stable stable;
    private volatile SenderData senderData;
    private volatile Stable stableRXT;
    public void setMT() {
        myTimer = new MyTimer(window, gamma, ds, record, beginTime, senderData, stableRXT);
    }
    public String getFileName() {
        return fileName;
    }
    public void setSenderData(int fSize) {
        senderData = new SenderData(fSize);
    }
    public long getNextSeq() {
        return nextSeq;
    }
    public long getNextAck() {
        return nextAck;
    }
    public void setNextSeq(long nextSeq) {
        this.nextSeq = nextSeq;
    }
    public void setNextAck(long nextAck) {
        this.nextAck = nextAck;
    }
    public DatagramSocket getDs() {
        return ds;
    }
    public float getTime() {
        return (float)(System.currentTimeMillis() - beginTime) / 1000F;
    }
    public Sender(String receiverHostIP, int receiverHostPort, String fileName, Integer MWS, Integer MSS, Integer gamma, float pDrop, float pDuplicate, float pCorrupt, float pOrder, int maxOrder, float pDelay, int maxDelay, int seed) {
        this.receiverHostIP = receiverHostIP;
        this.receiverHostPort = receiverHostPort;
        this.fileName = fileName;
        this.MWS = MWS;
        this.MSS = MSS;
        this.gamma = gamma;
        try {
            ds = new DatagramSocket();
            senderHostIP = InetAddress.getLocalHost().getHostAddress();
            senderHostPort = ds.getLocalPort();
        } catch (Exception e) {
            e.printStackTrace();
        }
        myPLD = new PLD(pDrop, pDuplicate, pCorrupt, pOrder, maxOrder, pDelay, maxDelay, seed);
        window = new Window(MWS);
        beginTime = System.currentTimeMillis();
        try {
            PrintWriter out = new PrintWriter(new File(fileName + "_SenderLog.txt").getAbsoluteFile());
            record = new Record(out);
        } catch (Exception e) {
            e.printStackTrace();
        }
        finAlready = false;
        stable = new Stable(-1L);
        stableRXT = new Stable(-1L);
    }
    public static void main(String []args) {
        try {
            if (args.length != 14)
                throw new IncorrectArgumentsException();
            Sender sender = new Sender(args[0], Integer.valueOf(args[1]), args[2], Integer.valueOf(args[3]), Integer.valueOf(args[4]), Integer.valueOf(args[5]), Float.valueOf(args[6]),
                                       Float.valueOf(args[7]), Float.valueOf(args[8]), Float.valueOf(args[9]), Integer.valueOf(args[10]), Float.valueOf(args[11]),
                                       Integer.valueOf(args[12]), Integer.valueOf(args[13]));
            UDPUtil udpUtil = new UDPUtil();
            UDPUtil.MyUtil mu = udpUtil.new MyUtil();
            byte []data = mu.readFile(sender.getFileName());
            sender.setSenderData(data.length);
            sender.setMT();
            DatagramSocket ds = sender.getDs();
            STP stp = new STP(sender.senderHostIP, sender.receiverHostIP, sender.senderHostPort, sender.receiverHostPort, 0, 0, sender.MWS, sender.MSS, true, false, false, false);
            stp.initSTP(new byte[0], true);
            byte []buffer = mu.listToArr(stp.getSegment());
            DatagramPacket dp = new DatagramPacket(buffer, buffer.length, InetAddress.getByName(sender.receiverHostIP), sender.receiverHostPort);
            sender.record.addRecord("snd", sender.getTime(), "S", 0, 0, 0);
            sender.senderData.increST();
            ds.send(dp);//send SYN
            while (true) {//receive SYN/ACK
                buffer = new byte[STP.getHeadLength()];
                dp = new DatagramPacket(buffer, buffer.length);
                ds.receive(dp);
                byte []gotData = dp.getData();
                sender.record.addRecord("rcv", sender.getTime(), "SA", STP.parseSeqNb(gotData).longValue(), 0, STP.parseAckNb(gotData).longValue());
                if (STP.isCS(STP.parseFlag(gotData)) == STP.outerCalculateCheckSum(mu.arrToList(gotData)) && STP.isSYN(STP.parseFlag(gotData)) && STP.isACK(STP.parseFlag(gotData))) {
                    sender.setNextAck(STP.parseSeqNb(gotData).longValue() + 1L);
                    sender.setNextSeq(STP.parseAckNb(gotData).longValue());
                    stp = new STP(sender.senderHostIP, sender.receiverHostIP, sender.senderHostPort, sender.receiverHostPort, sender.getNextSeq(), sender.getNextAck(), sender.MWS, sender.MSS, false, true, false, false);
                    stp.initSTP(new byte[0], true);
                    buffer = mu.listToArr(stp.getSegment());
                    dp = new DatagramPacket(buffer, buffer.length, InetAddress.getByName(sender.receiverHostIP), sender.receiverHostPort);
                    sender.record.addRecord("snd", sender.getTime(), "A", sender.getNextSeq(), 0, sender.getNextAck());
                    sender.senderData.increST();
                    ds.send(dp);//send ACK
                    break;
                }
            }
            UDPUtil.SendUDP mySender = udpUtil.new SendUDP(ds, sender.senderHostIP, sender.receiverHostIP, sender.senderHostPort, sender.receiverHostPort, true, sender.window, data, 1L, 1L, sender.MSS, sender.beginTime, sender.record, sender.stable, sender.myTimer, sender.myPLD, sender.senderData, sender.stableRXT);
            UDPUtil.ReceiveUDP myReceiver = udpUtil.new ReceiveUDP(ds, true, sender.window, sender.beginTime, sender.record, sender.stable, sender.senderHostIP, sender.receiverHostIP, sender.senderHostPort, sender.receiverHostPort, sender.MSS, sender.myTimer, sender.senderData, sender.fileName, sender.stableRXT);
            ExecutorService exec = Executors.newCachedThreadPool();
            exec.execute(mySender);
            exec.execute(myReceiver);
            exec.shutdown();
        } catch(Exception e) {
            e.printStackTrace();
        }
        
    }
}
