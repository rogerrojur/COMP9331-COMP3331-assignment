import java.util.*;
import java.io.*;
import java.net.*;
import java.util.concurrent.*;

class Stable {
    private volatile Long nextNeededAck;
    public Stable(Long nna) {
        nextNeededAck = nna;
    }
    public synchronized void setValue(Long nna) {
        nextNeededAck = nna;
    }
    public synchronized Long getValue() {
        return nextNeededAck;
    }
}

public class UDPUtil {
    class SendUDP implements Runnable {
        private MyTimer myTimer;
        private DatagramSocket ds;
        private String srcIP;
        private String destIP;
        private int srcPort;
        private int destPort;
        private volatile long nextSeq;
        private volatile long nextAck;
        private boolean isSender;
        private volatile Window window;
        private volatile Boolean finAlready;
        private byte []data;
        private int MSS;
        private long startTime;
        private Record record;
        private Stable stable;//init as -1
        private PLD myPLD;
        private ReOrder reOrder;
        private volatile SenderData senderData;
        private volatile Stable stableRXT;
        public SendUDP(DatagramSocket ds, String srcIP, String destIP, int srcPort, int destPort, boolean isSender, Window window, byte []data, long nextSeq, long nextAck, int MSS, long startTime, Record record, Stable stable, MyTimer myTimer, PLD myPLD, SenderData senderData, Stable stableRXT) {//destIP, destPort, stp; sender
            this.ds = ds;
            this.srcIP = srcIP;
            this.destIP = destIP;
            this.srcPort = srcPort;
            this.destPort = destPort;
            this.isSender = isSender;
            this.window = window;
            finAlready = false;
            this.data = data;
            this.nextSeq = nextSeq;
            this.nextAck = nextAck;
            this.MSS = MSS;
            this.startTime = startTime;
            this.record = record;
            this.stable = stable;
            this.myTimer = myTimer;
            this.myPLD = myPLD;
            reOrder = new ReOrder();
            this.senderData = senderData;
            this.stableRXT = stableRXT;
        }
        public float getTime() {
            return (float)(System.currentTimeMillis() - startTime) / 1000F;
        }
        public byte[] getData() {
            return data;
        }
        public void setData(byte []newData) {
            data = newData;
        }
        public void run() {
            try {
                if (isSender) {
                    MyUtil mu = new MyUtil();
                    while (!finAlready && getData().length != 0) {
                        //System.out.println(window);
                        STP stp = new STP(srcIP, destIP, srcPort, destPort, nextSeq, nextAck, window.getMaxWinSize(), MSS, false, false, false, false);
                        byte []newData = stp.initSTP(getData(), true);
                        if (window.canSend(stp) && !window.containSTP(stp)) {
                            synchronized(window) {
                                //System.out.println(stp);
                                window.addToWin(stp);
                                //System.out.println(window);
                                //System.out.println("window not empty: " + window.winNotEmpty());
                                if (window.winNotEmpty() && !myTimer.checkState() && stableRXT.getValue() < window.getFirst().getSeqNb().longValue()) {
                                    myTimer.callNewSeg();
                                }
                            }
                            boolean curReOrder = false;
                            byte []buffer = mu.listToArr(stp.getSegment());
                            int len = stp.getPayLoadLength();
                            String myDecision = myPLD.decision();
                            if (myDecision.equals("Drop")) {
                                record.addRecord("drop", getTime(), "D", stp.getSeqNb(), len, stp.getAckNb());
                                senderData.increST();
                                senderData.increSBP();
                                senderData.increSDr();
                                //all need to do
                                nextSeq += len;
                                setData(newData);
                                if (getData().length == 0)
                                    stable.setValue(nextSeq);
                            } else if (myDecision.equals("Duplicate")) {
                                DatagramPacket dp = new DatagramPacket(buffer, buffer.length, InetAddress.getByName(destIP), destPort);
                                record.addRecord("snd", getTime(), "D", stp.getSeqNb(), len, stp.getAckNb());
                                senderData.increST();
                                senderData.increSBP();
                                record.addRecord("snd/dup", getTime(), "D", stp.getSeqNb(), len, stp.getAckNb());
                                senderData.increST();
                                senderData.increSBP();
                                senderData.increSDu();
                                //all need to do
                                nextSeq += len;
                                setData(newData);
                                if (getData().length == 0)
                                    stable.setValue(nextSeq);
                                ds.send(dp);
                                ds.send(dp);
                            } else if (myDecision.equals("Corrupt")) {
                                buffer = STP.corruptSegment(buffer);
                                DatagramPacket dp = new DatagramPacket(buffer, buffer.length, InetAddress.getByName(destIP), destPort);
                                record.addRecord("snd/corr", getTime(), "D", stp.getSeqNb(), len, stp.getAckNb());
                                senderData.increST();
                                senderData.increSBP();
                                senderData.increSC();
                                //all need to do
                                nextSeq += len;
                                setData(newData);
                                if (getData().length == 0)
                                    stable.setValue(nextSeq);
                                ds.send(dp);
                            } else if (myDecision.equals("ReOrder")) {
                                if (reOrder.canReOrder()) {
                                    reOrder.newReOrder(stp, myPLD.getReOrder());
                                    curReOrder = true;
                                    //all need to do
                                    nextSeq += len;
                                    setData(newData);
                                    if (getData().length == 0)
                                        stable.setValue(nextSeq);
                                } else {//only one segment can be reordered
                                    DatagramPacket dp = new DatagramPacket(buffer, buffer.length, InetAddress.getByName(destIP), destPort);
                                    record.addRecord("snd", getTime(), "D", stp.getSeqNb(), len, stp.getAckNb());
                                    senderData.increST();
                                    senderData.increSBP();
                                    //all need to do
                                    nextSeq += len;
                                    setData(newData);
                                    if (getData().length == 0)
                                        stable.setValue(nextSeq);
                                    ds.send(dp);
                                }
                            } else if (myDecision.equals("Delay")) {
                                int myDelay = myPLD.getDelay();
                                DatagramPacket dp = new DatagramPacket(buffer, buffer.length, InetAddress.getByName(destIP), destPort);
                                long tempSeq = nextSeq, tempAck = nextAck;
                                //all need to do
                                nextSeq += len;
                                setData(newData);
                                if (getData().length == 0)
                                    stable.setValue(nextSeq);
                                new Thread(new Runnable() {
                                    @Override
                                    public void run() {
                                        try {
                                            long thisSeq = tempSeq, thisAck = tempAck;
                                            int thisLen = len;
                                            DatagramPacket thisdp = dp;
                                            Thread.sleep(myDelay);
                                            record.addRecord("snd/dely", getTime(), "D", thisSeq, thisLen, thisAck);
                                            senderData.increST();
                                            senderData.increSBP();
                                            senderData.increSDe();
                                            ds.send(thisdp);
                                        } catch (InterruptedException | IOException e) {
                                            e.printStackTrace();
                                        }
                                    }
                                }).start();
                            } else {//forward
                                DatagramPacket dp = new DatagramPacket(buffer, buffer.length, InetAddress.getByName(destIP), destPort);
                                record.addRecord("snd", getTime(), "D", stp.getSeqNb(), len, stp.getAckNb());
                                senderData.increST();
                                senderData.increSBP();
                                //all need to do
                                nextSeq += len;
                                setData(newData);
                                if (getData().length == 0)
                                    stable.setValue(nextSeq);
                                ds.send(dp);
                            }
                            if (!curReOrder) {
                                //System.out.println(reOrder);
                                STP reorderSeg = reOrder.process();
                                if (reorderSeg != null) {
                                    buffer = mu.listToArr(reorderSeg.getSegment());
                                    DatagramPacket dp = new DatagramPacket(buffer, buffer.length, InetAddress.getByName(destIP), destPort);
                                    record.addRecord("snd/rord", getTime(), "D", reorderSeg.getSeqNb(), reorderSeg.getPayLoadLength(), reorderSeg.getAckNb());
                                    senderData.increST();
                                    senderData.increSBP();
                                    senderData.increSRO();
                                    //all need to do
                                    ds.send(dp);
                                }
                            }
                        } else {
                        }
                    }
                    while (!finAlready) {
                        /*
                        synchronized(this) {
                            if (window.winNotEmpty() && !myTimer.checkState()) {
                                myTimer.callNewSeg();
                            }
                        }
                         */
                        if(stable.getValue() == -2L) {//last ack accepted
                            STP stp = new STP(srcIP, destIP, srcPort, destPort, nextSeq, nextAck, window.getMaxWinSize(), MSS, false, false, true, false);
                            stp.initSTP(new byte[0], true);
                            byte []buffer = mu.listToArr(stp.getSegment());
                            DatagramPacket dp = new DatagramPacket(buffer, buffer.length, InetAddress.getByName(destIP), destPort);
                            record.addRecord("snd", getTime(), "F", stp.getSeqNb(), 0, stp.getAckNb());
                            ds.send(dp);
                            finAlready = true;
                            senderData.increST();
                        }
                    }
                    //the receiveUDP can receive ack and send ack for the server's fin
                }
            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                //System.out.println("udpsend end");
                //do nothing
            }
        }
    }
    class ReceiveUDP implements Runnable {
        private String fName;
        private MyTimer myTimer;
        private String storeFileName;
        private LinkedList<Byte> content;
        private DatagramSocket ds;
        private String srcIP;
        private String destIP;
        private int srcPort;
        private int destPort;
        private volatile long nextSeq;
        private volatile long nextAck;
        private boolean isSender;
        private volatile Window window;
        private volatile Boolean finAlready;
        private int MSS;
        private long startTime;
        private Record record;
        private volatile Stable stable;
        private long newestAck;
        private int daCounter;
        private volatile SenderData senderData;
        private volatile ReceiverData receiverData;
        private volatile Stable stableRXT;
        public DatagramSocket getSocket() {
            return ds;
        }
        public float getTime() {
            return (float)(System.currentTimeMillis() - startTime) / 1000F;
        }
        public ReceiveUDP(DatagramSocket ds, boolean isSender, Window window, long startTime, Record record, Stable stable, String srcIP, String destIP, int srcPort, int destPort, int MSS, MyTimer myTimer, SenderData senderData, String fName, Stable stableRXT) {//sender
            this.ds = ds;
            this.isSender = isSender;
            this.window = window;
            this.startTime = startTime;
            this.record = record;
            this.stable = stable;
            finAlready = false;
            this.srcIP = srcIP;
            this.destIP = destIP;
            this.srcPort = srcPort;
            this.destPort = destPort;
            this.MSS = MSS;
            this.myTimer = myTimer;
            newestAck = 1;
            daCounter = 0;
            this.senderData = senderData;
            this.fName = fName;
            this.stableRXT = stableRXT;
        }
        public ReceiveUDP(String storeFileName, DatagramSocket ds, String srcIP, String destIP, int srcPort, int destPort, long nextSeq, long nextAck, boolean isSender, Window window, int MSS, long startTime, Record record, ReceiverData receiverData) {//receiver
            this.storeFileName = storeFileName;
            content = new LinkedList<Byte>();
            this.ds = ds;
            this.srcIP = srcIP;
            this.destIP = destIP;
            this.srcPort = srcPort;
            this.destPort = destPort;
            this.nextSeq = nextSeq;
            this.nextAck = nextAck;
            this.isSender = isSender;
            this.window = window;
            this.MSS = MSS;
            this.startTime = startTime;
            this.record = record;
            finAlready = false;
            this.receiverData = receiverData;
            this.fName = storeFileName;
        }
        public LinkedList<Byte> getContent() {
            return content;
        }
        public void run() {
            MyUtil mu = new MyUtil();
            File file = null;
            FileOutputStream fop = null;
            try{
                if (!isSender) {
                    try {
                        file = new File(fName);
                        fop = new FileOutputStream(file);
                        if (!file.exists())
                            file.createNewFile();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
                long finAckNb = 0L;
                long lastTime = System.currentTimeMillis();//check
                long lastFastSeq = -1L;
                int updateTimes = 0;
                //long lastRXTSeq = -1L;
                while(!finAlready) {
                    byte []buffer = new byte[STP.getHeadLength() + MSS];
                    DatagramPacket dp = new DatagramPacket(buffer, buffer.length);
                    ds.receive(dp);
                    byte []gotData = dp.getData();
                    LinkedList<Byte> temp = mu.arrToList(gotData);
                    mu.adjList(temp, MSS, STP.parsePayLoadLength(gotData));
                    gotData = mu.listToArr(temp);
                    if (!isSender) {//receiver
                        //System.out.println(window);
                        if (STP.isCS(STP.parseFlag(gotData)) == STP.outerCalculateCheckSum(mu.arrToList(gotData)) && !STP.isFIN(STP.parseFlag(gotData))) {//CS correct
                            STP stp = new STP(gotData);
                            byte []myPL = STP.extractPayLoad(gotData);
                            stp.initSTP(myPL);
                            record.addRecord("rcv", getTime(), "D", stp.getSeqNb(), stp.getPayLoadLength(), stp.getAckNb());
                            receiverData.increAODR(myPL.length);
                            receiverData.increTSR();
                            receiverData.increDSR();
                            long preAck = nextAck;
                            if (!window.containSTP(stp) && window.canReceive(stp)) {
                                window.insertToWin(stp);
                                //System.out.println(window);
                                //check can move window? and update the base, add the value to content
                                //content.addAll(window.moveWin());
                                LinkedList<Byte> temptemp = window.moveWin();
                                content.addAll(temptemp);
                                try {
                                    fop.write(mu.listToArr(temptemp));
                                    fop.flush();
                                } catch (IOException e) {
                                    e.printStackTrace();
                                }
                                //System.out.println("after move: " + window);
                            } else {//duplicate data
                                receiverData.increDDSR();
                            }
                            //send ack
                            nextAck = window.getBase().longValue();
                            stp = new STP(srcIP, destIP, srcPort, destPort, nextSeq, nextAck, window.getMaxWinSize(), MSS, false, true, false, false);
                            if (preAck != nextAck)
                                record.addRecord("snd", getTime(), "A", stp.getSeqNb(), 0, stp.getAckNb());//send ack
                            else {
                                record.addRecord("snd/DA", getTime(), "A", stp.getSeqNb(), 0, stp.getAckNb());//send dupAck
                                receiverData.increDAS();
                            }
                            stp.initSTP(new byte[0], true);
                            buffer = mu.listToArr(stp.getSegment());
                            dp = new DatagramPacket(buffer, buffer.length, InetAddress.getByName(destIP), destPort);
                            //System.out.println(stp);
                            ds.send(dp);
                        } else if (STP.isCS(STP.parseFlag(gotData)) == STP.outerCalculateCheckSum(mu.arrToList(gotData)) && STP.isFIN(STP.parseFlag(gotData))) {
                            STP stp = new STP(gotData);
                            stp.initSTP(new byte[0], true);
                            record.addRecord("rcv", getTime(), "F", stp.getSeqNb(), 0, stp.getAckNb());
                            receiverData.increTSR();
                            nextAck = stp.getSeqNb() + 1L;
                            stp = new STP(srcIP, destIP, srcPort, destPort, 1L, nextAck, window.getMaxWinSize(), MSS, false, true, false, false);
                            stp.initSTP(new byte[0], true);
                            //System.out.println(stp);
                            record.addRecord("snd", getTime(), "A", 1L, 0, nextAck);
                            buffer = mu.listToArr(stp.getSegment());
                            dp = new DatagramPacket(buffer, buffer.length, InetAddress.getByName(destIP), destPort);
                            ds.send(dp);
                            stp = new STP(srcIP, destIP, srcPort, destPort, 1L, nextAck, window.getMaxWinSize(), MSS, false, false, true, false);
                            stp.initSTP(new byte[0], true);
                            //System.out.println(stp);
                            record.addRecord("snd", getTime(), "F", 1L, 0, nextAck);
                            buffer = mu.listToArr(stp.getSegment());
                            dp = new DatagramPacket(buffer, buffer.length, InetAddress.getByName(destIP), destPort);
                            ds.send(dp);
                            finAckNb = 2L;
                            finAlready = true;
                        } else if (STP.isCS(STP.parseFlag(gotData)) != STP.outerCalculateCheckSum(mu.arrToList(gotData))) {//corrupt
                            lastTime = System.currentTimeMillis();
                            STP stp = new STP(gotData);
                            byte []myPL = STP.extractPayLoad(gotData);
                            stp.initSTP(myPL);
                            record.addRecord("rcv/corr", getTime(), "D", stp.getSeqNb(), stp.getPayLoadLength(), stp.getAckNb());
                            receiverData.increAODR(myPL.length);
                            receiverData.increTSR();
                            receiverData.increDSWBE();
                            receiverData.increDSR();
                        }
                    } else {//sender
                        boolean inside = false;
                        if (STP.isCS(STP.parseFlag(gotData)) == STP.outerCalculateCheckSum(mu.arrToList(gotData)) && STP.isACK(STP.parseFlag(gotData))) {
                            STP stp = new STP(gotData);
                            stp.initSTP(new byte[0], true);//add
                            long currentAck = stp.getAckNb().longValue();
                            if (currentAck > newestAck) {
                                newestAck = currentAck;
                                record.addRecord("rcv", getTime(), "A", stp.getSeqNb(), 0, stp.getAckNb());
                                daCounter = 0;
                            } else if (currentAck == newestAck) {
                                record.addRecord("rcv/DA", getTime(), "A", stp.getSeqNb(), 0, stp.getAckNb());
                                senderData.increDAR();
                                if (lastFastSeq != newestAck)//if this newestAck is not yet fast retran
                                    daCounter++;
                                if (lastFastSeq != newestAck && daCounter == 3) {// this will be the third
                                    System.out.println(daCounter);
                                    daCounter = 0;
                                    STP tempSTP = null;
                                    if (!window.winNotEmpty())
                                        Thread.sleep(200);
                                    try {
                                        tempSTP = window.findSTP(newestAck);
                                    } catch (Exception e) {
                                        e.printStackTrace();
                                    }
                                    lastFastSeq = tempSTP.getSeqNb().longValue();
                                    stableRXT.setValue(lastFastSeq);
                                    System.out.println("-----------------");
                                    System.out.println("--" + String.valueOf(lastFastSeq) + "--");
                                    System.out.println("-----------------");
                                    record.addRecord("snd/RXT", getTime(), "D", tempSTP.getSeqNb(), tempSTP.getPayLoadLength(), tempSTP.getAckNb());
                                    senderData.increST();
                                    senderData.increSBP();
                                    senderData.increFRT();
                                    buffer = mu.listToArr(tempSTP.getSegment());
                                    dp = new DatagramPacket(buffer, buffer.length, InetAddress.getByName(tempSTP.getDestIP()), tempSTP.getDestPort());
                                    myTimer.setFR(lastFastSeq);
                                    ds.send(dp);
                                }
                            } else {//this ack is too old
                                record.addRecord("rcv/DA", getTime(), "A", stp.getSeqNb(), 0, stp.getAckNb());
                                senderData.increDAR();
                            }
                            stp.initSTP(new byte[0], true);
                            if (myTimer.canCancel(stp.getAckNb().longValue())) {
                                inside = true;
                                System.out.println("thisSeqNb: " + String.valueOf(myTimer.getCurSeq()));
                                myTimer.cancelMT();
                                System.out.println(++updateTimes);
                                //System.out.println(window);
                            }
                            if (window.winNotEmpty()) {
                                window.nextBase(stp);
                                System.out.println(window);
                                //System.out.println("newAck: " + newestAck + ";curAck: " + currentAck);
                                //System.out.println(window);
                            }
                            if (inside) {
                                myTimer.cancelMT2();
                            }
                            synchronized(window) {
                                if (window.winNotEmpty() && !myTimer.checkState() && stableRXT.getValue() != window.getFirst().getSeqNb().longValue())
                                    myTimer.callNewSeg();
                            }
                            if (stable.getValue() >= 0) {//last seg was sent
                                if (stp.getAckNb().longValue() == stable.getValue().longValue()) {//last ack was received
                                    finAckNb = stable.getValue() + 1;//need for the finack
                                    stable.setValue(-2L);//inform the sendUDP thread
                                    finAlready = true;
                                }
                            }
                        }
                    }
                }
                if (isSender) {
                    boolean finAck = false;
                    boolean fin = false;
                    while(!finAck || !fin) {
                        byte []buffer = new byte[STP.getHeadLength()];
                        DatagramPacket dp = new DatagramPacket(buffer, buffer.length);
                        ds.receive(dp);
                        byte []gotData = dp.getData();
                        LinkedList<Byte> temp = mu.arrToList(gotData);
                        //mu.clearList(temp);
                        gotData = mu.listToArr(temp);
                        if (STP.isCS(STP.parseFlag(gotData)) == STP.outerCalculateCheckSum(mu.arrToList(gotData))) {
                            if (STP.isACK(STP.parseFlag(gotData)) && STP.parseAckNb(gotData).longValue() == finAckNb) {
                                record.addRecord("rcv", getTime(), "A", STP.parseSeqNb(gotData), 0, STP.parseAckNb(gotData));
                                finAck = true;
                            }
                            if (STP.isFIN(STP.parseFlag(gotData))) {
                                record.addRecord("rcv", getTime(), "F", STP.parseSeqNb(gotData), 0, STP.parseAckNb(gotData));
                                fin = true;
                                STP stp = new STP(srcIP, destIP, srcPort, destPort, STP.parseAckNb(gotData), 2L, window.getMaxWinSize(), MSS, false, true, false, false);
                                stp.initSTP(new byte[0], true);
                                record.addRecord("snd", getTime(), "A", STP.parseAckNb(gotData), 0, 2L);
                                senderData.increST();
                                buffer = mu.listToArr(stp.getSegment());
                                dp = new DatagramPacket(buffer, buffer.length, InetAddress.getByName(destIP), destPort);
                                ds.send(dp);
                            }
                        }
                    }
                } else {//receiver need to receive an single ack
                    boolean finAck = false;
                    while (!finAck) {
                        byte []buffer = new byte[STP.getHeadLength()];
                        DatagramPacket dp = new DatagramPacket(buffer, buffer.length);
                        ds.receive(dp);
                        byte []gotData = dp.getData();
                        LinkedList<Byte> temp = mu.arrToList(gotData);
                        //mu.clearList(temp);
                        gotData = mu.listToArr(temp);
                        if (STP.isCS(STP.parseFlag(gotData)) == STP.outerCalculateCheckSum(mu.arrToList(gotData)) && STP.isACK(STP.parseFlag(gotData)) && STP.parseAckNb(gotData).longValue() == finAckNb) {
                            record.addRecord("rcv", getTime(), "A", STP.parseSeqNb(gotData), 0, STP.parseAckNb(gotData));
                            receiverData.increTSR();
                            finAck = true;
                        }
                    }
                    /*
                    System.out.println("please wait for writing file");
                    mu.writeFile(mu.listToArr(content), storeFileName);//need to be change
                    System.out.println("finish!");
                     */
                }
                if (record == null)
                    System.out.println("fuck!!");
            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                try {
                    Thread.sleep(1000);
                } catch (Exception e) {
                    e.printStackTrace();
                }
                if (senderData != null) {
                    System.out.println(senderData);
                    record.writeContent(senderData.toString());
                }
                if (receiverData != null) {
                    System.out.println(receiverData);
                    record.writeContent(receiverData.toString());
                }
                try {
                    if (fop != null)
                        fop.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
                if (ds != null)
                    ds.close();
                if (myTimer != null)
                    myTimer.dispose();
                if (record != null)
                    record.dispose();
            }
        }
    }
    class MyUtil {
        public void adjList(LinkedList<Byte> source, int MSS, int payLoadLength) {
            for (int i = source.size() - 1, j = 0; i > 0 && MSS - payLoadLength > j; i --, j++)
                source.removeLast();
        }
        public void clearList(LinkedList<Byte> source) {
            for (int i = source.size() - 1; i >= 0 && source.get(i).byteValue() == (byte)0; i--)
                source.removeLast();
        }
        public byte[] listToArr(LinkedList<Byte> source) {
            byte []arr = new byte[source.size()];
            for (int i = 0; i < source.size(); i++)
                arr[i] = source.get(i).byteValue();
            return arr;
        }
        public LinkedList<Byte> arrToList(byte[] source) {
            LinkedList<Byte> list = new LinkedList<Byte>();
            for (int i = 0; i < source.length; i++)
                list.add(Byte.valueOf(source[i]));
            return list;
        }
        public byte[] readFile(String fileName) {
            byte []data = null;
            try {
                BufferedInputStream bf = new BufferedInputStream(new FileInputStream(new File(fileName).getAbsoluteFile()));
                try {
                    data = new byte[bf.available()];
                    bf.read(data);
                } finally {
                    bf.close();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            return data;
        }
        /*
        public String readFile(String fileName) {
            File file = null;
            BufferedReader bReader = null;
            StringBuilder sb = null;
            try {
                file = new File(fileName);
                bReader = new BufferedReader(new FileReader(file));
                sb = new StringBuilder();
                String s = null;
                while ((s = bReader.readLine()) != null) {
                    sb.append(s).append(System.getProperty("line.separator"));
                }
            } catch (IOException e) {
                e.printStackTrace();
            } finally {
                try {
                    if (bReader != null)
                        bReader.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
                return sb.toString();
            }
        }
         */
        public void easyWrite(LinkedList list, String data, String fileName) {
            writeFile(list, data, fileName + "_log.txt");
        }
        public void writeFile(LinkedList list, String data, String fileName) {
            try {
                PrintWriter out = new PrintWriter(new File(fileName).getAbsoluteFile());
                try {
                    for (int i = 0; i < list.size(); i++)
                        out.println(list.get(i).toString());
                    out.print(data);
                } finally {
                    out.close();
                }
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }
        public void writeFile(byte []data, String fileName) {
            File file = null;
            FileOutputStream fop = null;
            try {
                file = new File(fileName);
                fop = new FileOutputStream(file);
                if (!file.exists())
                    file.createNewFile();
                fop.write(data);
                fop.flush();
            } catch (IOException e) {
                e.printStackTrace();
            } finally {
                try {
                    if (fop != null)
                        fop.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }
    public static void main(String []args) {
        UDPUtil uu = new UDPUtil();
        UDPUtil.MyUtil mu = uu.new MyUtil();
        System.out.println(mu.readFile("test0.pdf").length);
    }
}
