import java.util.*;
import java.net.*;

public class MyTimer {
    private TimerTask curTT;
    private volatile Record record;
    private DatagramSocket ds;
    private volatile STP curSTP;
    private volatile long ERTT;//ERTT = ERTT*(1-a) + SRTT*a
    private float a;
    private volatile long DRTT;//DRTT = DRTT*(1-b) + Math.abs(SRTT - ERTT)*b
    private float b;
    private int gamma;
    private volatile long timeOutInterval;//timeOutInterval = ERTT + gamma*DRTT
    private volatile Window window;
    private volatile boolean working;
    private volatile Timer timer;
    private volatile boolean isRXT;
    private long udpTime;
    private volatile long startTime;
    private SenderData senderData;
    private int updateTimes;
    private volatile Stable stableRXT;
    private volatile long expectedAck;// if receive ack segment's ack >= this value, it means it get the rtt, expectedAck = seqNb + payLoad.size()
    public MyTimer(Window window, int gamma, DatagramSocket ds, Record record, long udpTime, SenderData senderData, Stable stableRXT) {
        timer = new Timer();
        this.window = window;
        working = false;
        ERTT = 500L;
        DRTT = 250L;
        this.gamma = gamma;
        a = 0.125F;
        b = 0.25F;
        timeOutInterval = ERTT + (long)gamma*DRTT;
        System.out.println("new RTO: " + timeOutInterval);
        this.ds = ds;
        this.record = record;
        this.udpTime = udpTime;
        this.senderData = senderData;
        updateTimes = 0;
        this.stableRXT = stableRXT;
    }
    public synchronized boolean setFR(long seqNb) {
        if (checkState()) {
            if (curSTP.getSeqNb().longValue() <= seqNb) {
                setRXT();
                return true;
            }
        }
        return false;
    }
    public synchronized void setRXT() {
        isRXT = true;
    }
    public synchronized long getCurSeq() {
        return curSTP.getSeqNb().longValue();
    }
    public synchronized boolean checkState() {
        return working;
    }
    public synchronized boolean canCancel(long ackNb) {
        //System.out.println("thisAck: " + ackNb + "; " + "expectedAck: " + expectedAck);
        if(checkState() && ackNb >= expectedAck)
            return true;
        return false;
    }
    public synchronized void callNewSeg() {
        if (!working) {
            working = true;
            isRXT = false;
            startTime = System.currentTimeMillis();
            try {
                curSTP = window.getFirst();
            } catch (Exception e) {
                e.printStackTrace();
            }
            System.out.println("curSTP: " + String.valueOf(curSTP.getSeqNb().longValue()));
            //System.out.println(curSTP.getPayLoadSize().intValue());
            expectedAck = curSTP.getSeqNb() + Long.valueOf(curSTP.getPayLoadSize().intValue());
            //System.out.println(expectedAck);
            curTT = new TimerTask() {
                    @Override
                    public void run() {
                        synchronized(this) {
                            //System.out.println(curSTP);
                            if (stableRXT.getValue() < curSTP.getSeqNb().longValue()) {
                                isRXT = true;
                                UDPUtil uu = new UDPUtil();
                                UDPUtil.MyUtil mu = uu.new MyUtil();
                                try {
                                    byte []buffer = mu.listToArr(curSTP.getSegment());
                                    DatagramPacket dp = new DatagramPacket(buffer, buffer.length, InetAddress.getByName(curSTP.getDestIP()), curSTP.getDestPort().intValue());
                                    int len = curSTP.getPayLoadLength();
                                    System.out.println("****************");
                                    System.out.println("**" + String.valueOf(curSTP.getSeqNb().longValue()) + "**");
                                    System.out.println("****************");
                                    record.addRecord("snd/RXT", getUdpTime(), "D", curSTP.getSeqNb(), len, curSTP.getAckNb());
                                    senderData.increST();
                                    senderData.increSBP();
                                    senderData.increRTTO();
                                    stableRXT.setValue(curSTP.getSeqNb().longValue());
                                    ds.send(dp);
                                } catch(Exception e) {
                                    e.printStackTrace();
                                }
                            }
                        }
                    }
                };
            timer.schedule(curTT, timeOutInterval);
        }
    }
    public long getTime() {
        return System.currentTimeMillis() - startTime;
    }
    public float getUdpTime() {
        return (float)(System.currentTimeMillis() - udpTime) / 1000F;
    }
    public synchronized void updateTO() {
        long SRTT = getTime();
        ERTT = (long)((double)ERTT * (double)(1F - a) + (double)SRTT * (double)a);
        DRTT = (long)((double)DRTT * (double)(1F - b) + (double)(Math.abs(SRTT - ERTT)) * (double)b);
        timeOutInterval = ERTT + (long)gamma * DRTT;
        if (timeOutInterval < 100L)
            timeOutInterval = 100L;
        System.out.println("newSRTT: " + SRTT);
        System.out.println("newERTT: " + ERTT);
        System.out.println("newDRTT: " + DRTT);
        System.out.println("newROT: " + timeOutInterval);
        System.out.println("already update: " + String.valueOf(++updateTimes));
    }
    public synchronized void cancelMT() {
        curTT.cancel();
        timer.purge();
        if (!isRXT)
            updateTO();
        //working = false;
        isRXT = false;
    }
    public synchronized void cancelMT2() {
        working = false;
    }
    public void dispose() {
        timer.purge();
        timer.cancel();
    }
}
