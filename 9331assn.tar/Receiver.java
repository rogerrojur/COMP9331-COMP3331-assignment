import java.io.*;
import java.net.*;
import java.util.*;
import java.util.concurrent.*;

class ReceiverData {
    private volatile int amountOfDataReceived;
    private volatile int totalSegRece;
    private volatile int dataSegRece;
    private volatile int dataSegWithBitErr;
    private volatile int dupDataSegRece;
    private volatile int dupAckSent;
    private int getSpace(int len1, int len2) {
        return 100 - len1 - len2;
    }
    private String small(String s, int i) {
        StringBuilder sb = new StringBuilder();
        sb.append(s);
        for (int j = 0; j < getSpace(s.length(), String.valueOf(i).length()); j++)
            sb.append(" ");
        sb.append(String.valueOf(i));
        return sb.toString();
    }
    private String slark() {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 100; i++)
            sb.append("=");
        sb.append(System.getProperty("line.separator"));
        return sb.toString();
    }
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(slark());
        sb.append(small("Amount of data received (bytes)", amountOfDataReceived)).append(System.getProperty("line.separator"));
        sb.append(small("Total Segments Received", totalSegRece)).append(System.getProperty("line.separator"));
        sb.append(small("Data segments received", dataSegRece)).append(System.getProperty("line.separator"));
        sb.append(small("Data segments with Bit Errors", dataSegWithBitErr)).append(System.getProperty("line.separator"));
        sb.append(small("Duplicate data segments received", dupDataSegRece)).append(System.getProperty("line.separator"));
        sb.append(small("Duplicate ACKs sent", dupAckSent)).append(System.getProperty("line.separator"));
        sb.append(slark());
        return sb.toString();
    }
    public synchronized int getAODR() {
        return amountOfDataReceived;
    }
    public synchronized int getTSR() {
        return totalSegRece;
    }
    public synchronized int getDSR() {
        return dataSegRece;
    }
    public synchronized int getDSWBE() {
        return dataSegWithBitErr;
    }
    public synchronized int getDDSR() {
        return dupDataSegRece;
    }
    public synchronized int getDAS() {
        return dupAckSent;
    }
    public synchronized void increAODR(int value) {
        amountOfDataReceived += value;
    }
    public synchronized void increTSR() {
        totalSegRece++;
    }
    public synchronized void increDSR() {
        dataSegRece++;
    }
    public synchronized void increDSWBE() {
        dataSegWithBitErr++;
    }
    public synchronized void increDDSR() {
        dupDataSegRece++;
    }
    public synchronized void increDAS() {
        dupAckSent++;
    }
}

public class Receiver {
    private Window window;
    private DatagramSocket ds;
    private String senderHostIP;
    private int senderHostPort;
    private String receiverHostIP;
    private int receiverHostPort;
    private String fileName;
    private long nextSeq;
    private long nextAck;
    private Integer MWS;//need to be reset later
    private Integer MSS;//need to be reset later
    private long beginTime;
    private Record record;
    private volatile Boolean finAlready;
    private volatile ReceiverData receiverData;
    public String getFileName() {
        return fileName;
    }
    public long getNextSeq() {
        return nextSeq;
    }
    public long getNextAck() {
        return nextAck;
    }
    public void setNextSeq(long nextSeq) {
        this.nextSeq = nextSeq;
    }
    public void setNextAck(long nextAck) {
        this.nextAck = nextAck;
    }
    public DatagramSocket getDs() {
        return ds;
    }
    public float getTime() {
        return (float)(System.currentTimeMillis() - beginTime) / 1000F;
    }
    public Receiver(int receiverPort, String fileName) {
        receiverHostPort = receiverPort;
        this.fileName = fileName;
        MSS = 0;
        MWS = 0;
        try {
            receiverHostIP = InetAddress.getLocalHost().getHostAddress();
            ds = new DatagramSocket(receiverPort);
        } catch (Exception e) {
            e.printStackTrace();
        }
        beginTime = System.currentTimeMillis();
        try {
            PrintWriter out = new PrintWriter(new File(fileName + "_ReceiverLog.txt").getAbsoluteFile());
            record = new Record(out);
        } catch (Exception e) {
            e.printStackTrace();
        }
        finAlready = false;
        receiverData = new ReceiverData();
        //window = null;senderHostIP = null;senderHostPort = null;
    }
    public void setValue(String senderIP, int senderPort, int MWS, int MSS) {
        senderHostIP = senderIP;
        senderHostPort = senderPort;
        this.MWS = MWS;
        this.MSS = MSS;
    }
    public static void main(String []args) {
        try {
            if (args.length != 2)
                throw new IncorrectArgumentsException();
        } catch (IncorrectArgumentsException e) {
            e.printStackTrace();
        }
        Receiver receiver = new Receiver(Integer.valueOf(args[0]).intValue(), args[1]);
        UDPUtil udpUtil = new UDPUtil();
        UDPUtil.MyUtil mu = udpUtil.new MyUtil();
        byte []buffer = null;
        DatagramPacket dp = null;
        try {
            DatagramSocket ds = receiver.getDs();
            while (true) {//receive SYN and send SYN/ACK
                buffer = new byte[STP.getHeadLength()];//0 size of payLoad
                dp = new DatagramPacket(buffer, buffer.length);
                ds.receive(dp);
                byte []gotData = dp.getData();
                receiver.record.addRecord("rcv", receiver.getTime(), "S", STP.parseSeqNb(gotData).longValue(), 0, STP.parseAckNb(gotData).longValue());
                receiver.receiverData.increTSR();
                if (STP.parseCheckSum(gotData) == STP.outerCalculateCheckSum(mu.arrToList(gotData)) && STP.isSYN(STP.parseFlag(gotData))){
                    receiver.setValue(STP.parseSrcIP(gotData), STP.parseSrcPort(gotData).intValue(), STP.parseMWS(gotData).intValue(), STP.parseMSS(gotData).intValue());
                    receiver.setNextAck(STP.parseSeqNb(gotData).longValue() + 1L);
                    receiver.setNextSeq(STP.parseAckNb(gotData).longValue());
                    STP stp = new STP(receiver.receiverHostIP, receiver.senderHostIP, receiver.receiverHostPort, receiver.senderHostPort, receiver.getNextSeq(), receiver.getNextAck(), receiver.MWS, receiver.MSS, true, true, false, false);
                    stp.initSTP(new byte[0], true);
                    buffer = mu.listToArr(stp.getSegment());
                    dp = new DatagramPacket(buffer, buffer.length, InetAddress.getByName(receiver.senderHostIP), receiver.senderHostPort);
                    receiver.record.addRecord("snd", receiver.getTime(), "SA", receiver.getNextSeq(), 0, receiver.getNextAck());
                    ds.send(dp);
                    break;
                }
            }
            while (true) {//receive ACK
                buffer = new byte[STP.getHeadLength()];
                dp = new DatagramPacket(buffer, buffer.length);
                ds.receive(dp);
                byte []gotData = dp.getData();
                if (STP.parseCheckSum(gotData) == STP.outerCalculateCheckSum(mu.arrToList(gotData)) && STP.isACK(STP.parseFlag(gotData))) {
                    receiver.setNextAck(STP.parseSeqNb(gotData).longValue());
                    receiver.setNextSeq(STP.parseAckNb(gotData).longValue());
                    receiver.window = new Window(receiver.MWS, receiver.getNextAck());
                    receiver.record.addRecord("rcv", receiver.getTime(), "A", STP.parseSeqNb(gotData).longValue(), 0, STP.parseAckNb(gotData).longValue());
                    receiver.receiverData.increTSR();
                    break;
                }
            }
            UDPUtil.ReceiveUDP myReceiver = udpUtil.new ReceiveUDP(receiver.fileName, ds, receiver.receiverHostIP, receiver.senderHostIP, receiver.receiverHostPort, receiver.senderHostPort, receiver.nextSeq, receiver.nextAck, false, receiver.window, receiver.MSS, receiver.beginTime, receiver.record, receiver.receiverData);
            ExecutorService exec = Executors.newCachedThreadPool();
            exec.execute(myReceiver);
            exec.shutdown();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
