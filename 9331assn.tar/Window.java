import java.util.*;

class EmptyWindowException extends Exception {}

public class Window {
    private volatile LinkedList<STP> window;//current window
    private volatile Integer windowSize;//the size of the window
    private volatile Long base;//means the beginning of the seqNb in this win
    public Window(int windowSize) {//sender
        this.windowSize = Integer.valueOf(windowSize);
        window = new LinkedList<STP>();
        base = 1L;
    }
    public Window(int windowSize, long base) {
        this(windowSize);
        this.base = Long.valueOf(base);
    }
    public synchronized Long getBase() {
        return base;
    }
    public synchronized void updateBase(long thisAck) {
        if (thisAck > base)
            base = thisAck;
    }
    @Override
    public synchronized String toString() {
        String content = "";
        for (int i = 0; i < window.size(); i++)
            content += " " + String.valueOf(window.get(i).getSeqNb());
        return "windowSize: " + windowSize + ";base: " + base + ";window: " + getWinLen() +
        ";windowSeq: " + content;
    }
    public synchronized boolean winNotEmpty() {
        return window != null && getWinLen() != 0;
    }
    public synchronized boolean nextBase(STP stp) throws EmptyWindowException {//for sender
        if (window == null || getWinLen() == 0) {
            throw new EmptyWindowException();
        } else {
            if (window.get(0).getSeqNb().longValue() >= stp.getAckNb())
                return false;//duplicate ack
            else {
                base = stp.getAckNb().longValue();
                while (winNotEmpty() && window.peek().getSeqNb().longValue() < base)
                    window.poll();
                return true;//success
            }
        }
    }
    public synchronized boolean nextBase(long ackNb) throws EmptyWindowException {//for sender
        if (window == null || getWinLen() == 0) {
            throw new EmptyWindowException();
        } else {
            if (window.get(0).getSeqNb().longValue() >= ackNb)
                return false;//duplicate ack
            else {
                base = ackNb;
                while (winNotEmpty() && window.peek().getSeqNb().longValue() < base)
                    window.poll();
                return true;//success
            }
        }
    }
    public synchronized LinkedList<Byte> moveWin() throws EmptyWindowException {//for receiver return the payLoad in order in LinkedList<Byte>
        LinkedList<Byte> list = new LinkedList<Byte>();
        if (window == null || getWinLen() == 0) {
            throw new EmptyWindowException();
        } else {
            while (window.size() != 0 && window.peek().getSeqNb().longValue() == base) {
                base = window.peek().getSeqNb().longValue() + (long)window.peek().getPayLoadSize();
                list.addAll(window.poll().getPayLoad());
            }
        }
        return list;
    }
    public synchronized STP getFirst() throws EmptyWindowException {
        if (window == null || getWinLen() == 0)
            throw new EmptyWindowException();
        return window.peek();
    }
    public synchronized int getMaxWinSize() {
        return windowSize.intValue();
    }
    private synchronized int getWinLen() {
        return window.size();
    }
    public synchronized int calculateWinSize() {
        int counter = 0;
        for (int i = 0; i < getWinLen(); i++)
            counter += window.get(i).getPayLoadSize();
        return counter;
    }
    public synchronized boolean canSend(STP stp) {
        if (calculateWinSize() + stp.getPayLoadSize() <= windowSize)
            return true;
        else
            return false;
    }
    public synchronized void insertToWin(STP stp) {
        if (window.size() == 0) {
            window.add(stp);
        } else {
            int index = 0;
            for (int i = 0; i < window.size(); i++)
                if (stp.getSeqNb() < window.get(i).getSeqNb()) {
                    index = i;
                    break;
                }
            if (stp.getSeqNb() > window.get(index).getSeqNb()) {
                window.add(stp);
            } else {
                window.add(index, stp);
            }
        }
    }
    public synchronized STP findSTP(long seqNb) throws EmptyWindowException {
        if (window == null || getWinLen() == 0)
            throw new EmptyWindowException();
        for (int i = 0; i < window.size(); i++)
            if (seqNb == window.get(i).getSeqNb())
                return window.get(i);
        return null;
    }
    public synchronized boolean containSTP(STP stp) {
        for (int i = 0; i < window.size(); i++)
            if (stp.getSeqNb().longValue() == window.get(i).getSeqNb().longValue())
                return true;
        return false;
    }
    public synchronized boolean canReceive(STP stp) {
        if (stp.getSeqNb() >= base && stp.getSeqNb() - base + stp.getPayLoadSize() <= windowSize && !containSTP(stp)) {
            return true;
        } else {
            return false;
        }
    }
    public synchronized boolean addToWin(STP stp) {//should first check if can send
        if (canSend(stp)) {
            window.offer(stp);
            return true;//success
        } else {
            return false;
        }
    }
    public synchronized void deleteFromWin() throws EmptyWindowException {
        if (window == null || getWinLen() == 0)
            throw new EmptyWindowException();
        window.poll();
    }
}
